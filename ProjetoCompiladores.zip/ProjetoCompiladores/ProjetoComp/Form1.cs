﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoComp
{
    public partial class Form1 : Form
    {
        static private List<Rotas> Rotas;
        public String Path_atual;
        public String Nome_atual;

        public Form1()
        {
            InitializeComponent();
            Rotas = new List<Rotas>();
        }
        private void b_correr_Click(object sender, EventArgs e)
        {
            String texto;
            texto = richTextBox1.Text;
            Analisador analisa = new Analisador();
            analisa.Analisador_cadeia(texto);

            analisa.gerarLista();
            comen.Text = analisa.getRetorno();

            analisa.gerarListaErros();
            erros.Text = analisa.getRetorno();
       
        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = string.Empty;
            comen.Text = string.Empty;
            erros.Text = string.Empty;
            
        }
       
        private void salvarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            salvarComo();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Nomes: \n\nDébora Rodrigues RA: 37828 \nFelipy Cavalcante RA: 96981 \nGuilherme Murilo RA: 96924 \nLucas de Matos Silva RA: 68515", "Sobre");
        }

        private void salvarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Boolean existe = false;
            string path = "";
            for (int i = 0; i < Rotas.Count; i++)
            {
                Rotas ru = Rotas.ElementAt(i);
                if (Path_atual == ru.getPath() )
                {
                    path = Path_atual;
                    existe = true;
                }
            }
            if (existe == false)
            {
                salvarComo();
            }
            else
            {
                salvar(path);
            }
        }

        private void salvar(string path)
        {
            try
            {
                string text = richTextBox1.Text;
                StreamWriter writer = new StreamWriter(path);
                writer.Write(text);
                writer.Flush();
                writer.Close();

                string Nome = Path.GetFileNameWithoutExtension(path);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private void salvarComo()
        {
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "[LFP]|*.txt";
            saveFile.Title = "salvar archivo";

            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                FileStream fs = (FileStream)saveFile.OpenFile();
                fs.Close();
                string path = saveFile.FileName;
                salvar(path);
                string Nome = Path.GetFileNameWithoutExtension(path);
                Rotas path_r = new Rotas(path, Nome);
                Rotas.Add(path_r);

                Path_atual = path;
                Nome_atual = Nome;
                this.Text = Nome_atual;

            }

        }

        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "[LFP]|*.txt";
            string texto = "";
            string fila = "";
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                string ruta1 = openFile.FileName;
                StreamReader streamReader = new StreamReader(ruta1, System.Text.Encoding.UTF8);
                string NomeC = Path.GetFileNameWithoutExtension(openFile.FileName);
                while ((fila = streamReader.ReadLine()) != null)
                {
                    texto += fila + System.Environment.NewLine;
                }
                richTextBox1.Text = texto;
                streamReader.Close();

                Rotas.Clear();
                Rotas path = new Rotas(ruta1, NomeC);
                Rotas.Add(path);

                Path_atual = ruta1;
                Nome_atual = NomeC;
                this.Text = Nome_atual;
    
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
