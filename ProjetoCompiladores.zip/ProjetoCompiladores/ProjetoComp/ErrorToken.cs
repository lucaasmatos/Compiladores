﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoComp
{
    class ErrorToken
    {

        private String lexema;
        private String idToken;
        private int linha;
        private int coluna;
        public ErrorToken(String lexema, String idToken, int linha, int coluna)
        {

            this.lexema = lexema;
            this.idToken = idToken;
            this.linha = linha;
            this.coluna = coluna;
        }
        public String getLexema()
        {
            return this.lexema;
        }
        public String getIdToken()
        {
            return this.idToken;
        }
        public int getlinha()
        {
            return this.linha;
        }
        public int getcoluna()
        {
            return this.coluna;
        }
    }
}
