﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoComp
{
 

    public class ExecutarGraficos
    {
        String Token_n;
        long idToken;
        Object lin_senten;
        String cadeia_oper;

        public ExecutarGraficos(long idToken, String Token_n, Object lin_senten, String cadeia_oper )
        {

            this.Token_n = Token_n;
            this.idToken = idToken;
            this.lin_senten = lin_senten;
            this.cadeia_oper = cadeia_oper;

        }

        public String getcadeia_oper()
        {
            return this.cadeia_oper;
        }

        public String getToken_n()
        {
            return this.Token_n;
        }
        public long getIdToken()
        {
            return this.idToken;
        }
        public Object getlin_senten()
        {
            return this.lin_senten;
        }

  
    }


}
