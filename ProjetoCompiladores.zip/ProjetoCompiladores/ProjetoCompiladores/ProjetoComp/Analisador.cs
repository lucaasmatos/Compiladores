﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoComp
{
    class Analisador
    {
        ArrayList tokens;
        ArrayList tipos;

        string reservadas;

        ArrayList Lista_Operaciones;
        static private List<Token> listaTokens;
        public List<LinhasExecutar> lin_ejecutar;
        public List<ExecutarGraficos> graf_ejecutar;
        private String retorno;
        public int estado_token;

        static private List<ErrorToken> listaErrores;

        public Analisador()
        {
            listaTokens = new List<Token>();
            tokens = new ArrayList();
            tipos = new ArrayList();
            reservadas = ";auto;double;int;struct;break;else;long;switch;case;enum;register;typedef;char;extern;return;union;const;float;short;unsigned;continue;for;signed;void;default;goto;sizeof;volatile;do;if;static;while;";
            reservadas += "var;break;char;string;class;alignas;alignof;and;and_eq;asm;auto;bitand;bitor;bool;catch;char;char16_t;char32_t;class;compl;const;constexpr;const_cast;continue;decltype;default;delete;do;double;dynamic_cast;";
            reservadas += "else;enum;explicit;export;extern;false;float;for;inline;int;long;mutable;namespace;new;noexcept;not;not_eq;nullptr;operator;or;or_eq;private;protected;public;register;reinterpret_cast;return;signed;sizeof;static";
            reservadas += "static_assert;static_cast;struct;switch;template;this;thread_local;throw;true;try;typedef;typeid;typename;union;unsigned;using;virtual;void;volatile;wchar_t;while;xor;xor_eq;";
            tokens.Add("Resultado");
            tokens.Add("Graficar");
            tokens.Add("Node");

            tipos.Add("Valor");
            tipos.Add("Operador");
            tipos.Add("IZQ");
            tipos.Add("DER");


            Lista_Operaciones = new ArrayList();
            lin_ejecutar = new List<LinhasExecutar>();
            graf_ejecutar = new List<ExecutarGraficos>();

            listaErrores = new List<ErrorToken>();

        }

        public void addToken(String lexema, String idToken, int linha, int coluna, int indice)
        {
            Token nuevo = new Token(lexema, idToken, linha, coluna, indice);
            listaTokens.Add(nuevo);
        }

        public void addError(String lexema, String idToken, int linha, int coluna)
        {
            ErrorToken errtok = new ErrorToken(lexema, idToken, linha, coluna);
            listaErrores.Add(errtok);
        }

        public void Analisador_cadeia(String entrada)
        {
            int estado = 0;
            int coluna = 0;
            int fila = 1;
            string lexema = "";
            Char c;
            entrada = entrada + " ";

            for (int i = 0; i < entrada.Length; i++)
            {
                c = entrada[i];
                coluna++;

                switch (estado)
                {
                    case 0:
                        if (Char.IsLetter(c))
                        {
                            estado = 1;
                            lexema += c;
                        }
                        else if (Char.IsDigit(c))
                        {
                            estado = 2;
                            lexema += c;
                            addToken(lexema, "Numerico", fila, coluna, i);
                            lexema = "";
                        }

                        else if (c == '"')
                        {
                            estado = 4;
                            i--;
                            coluna--;
                        }
                        else if (c == ',')
                        {
                            estado = 6;
                            i--;
                            coluna--;
                        }
                        else if (c == ' ')
                        {
                            estado = 0;
                        }
                        else if (c == '\n')
                        {
                            coluna = 0;
                            //i--;
                            fila++;
                            estado = 0;
                        }

                        else if (c == '{')
                        {
                            lexema += c;
                            addToken(lexema, "Chave Esq.", fila, coluna, i - lexema.Length);
                            lexema = "";
                        }
                        else if (c == '}')
                        {
                            lexema += c;
                            addToken(lexema, "Chave Dir.", fila, coluna, i - lexema.Length);
                            lexema = "";
                        }
                        else if (c == '(')
                        {
                            lexema += c;
                            addToken(lexema, "Parentese Esq.", fila, coluna, i - lexema.Length);
                            lexema = "";
                        }
                        else if (c == ')')
                        {
                            lexema += c;
                            addToken(lexema, "Parentese Dir.", fila, coluna, i - lexema.Length);
                            lexema = "";
                        }
                        else if (c == ',')
                        {
                            lexema += c;
                            lexema = "Virgula";
                        }

                        else if (c == ';')
                        {
                            lexema += c;
                            addToken(lexema, "Ponto e Virgula", fila, coluna, i - lexema.Length);
                            lexema = "";
                        }

                        else if (c == '<')
                        {
                            lexema += c;
                            addToken(lexema, "Menor", fila, coluna, i - lexema.Length);
                            lexema = "";
                        }
                        else if (c == '>')
                        {
                            lexema += c;
                            addToken(lexema, "Maior", fila, coluna, i - lexema.Length);
                            lexema = "";
                        }

                        else if (c == '.')
                        {
                            lexema += c;
                            addToken(lexema, "Ponto", fila, coluna, i - lexema.Length);
                            lexema = "";
                        }

                        else if (c == '+')
                        {
                            lexema += c;
                            addToken(lexema, "Soma", fila, coluna, i);
                            lexema = "";
                        }
                        else if (c == '-')
                        {
                            lexema += c;
                            addToken(lexema, "Hífen / Subtração", fila, coluna, i);
                            lexema = "";
                        }
                        else if (c == '*')
                        {
                            lexema += c;
                            addToken(lexema, "Asterisco / Multiplicação", fila, coluna, i);
                            lexema = "";
                        }
                        else if (c == '/')
                        {
                            lexema += c;
                            addToken(lexema, "Divisão / Barra", fila, coluna, i);
                            lexema = "";
                        }

                        else
                        {
                            estado = -99;
                            i--;
                            coluna--;
                        }
                        break;
                    case 1:

                        if (Char.IsLetterOrDigit(c) || c == '_')
                        {
                            lexema += c;
                            estado = 1;

                        }
                        else
                        {
                            Boolean encontrado = false;
                            encontrado = Macht_enReser(lexema);
                            if (encontrado)
                            {
                                addToken(lexema, "Palavra Reservada", fila, coluna, i - lexema.Length);
                            }
                            else
                            {
                                addToken(lexema, "Texto", fila, coluna, i - lexema.Length);
                            }
                            lexema = "";
                            i--;
                            coluna--;
                            estado = 0;
                        }
                        break;
                    case 2:
                        if (Char.IsDigit(c))
                        {
                            lexema += c;
                            estado = 2;
                            addToken(lexema, "Numerico", fila, coluna, i);
                        }

                        else if (c == '.')
                        {
                            estado = 8;
                            lexema += c;
                        }

                        else
                        {
                            lexema = "";
                            i--;
                            coluna--;
                            estado = 0;
                        }
                        break;
                    case 3:
                        if (Char.IsDigit(c))
                        {
                            lexema += c;
                            estado = 2;
                        }
                        else
                        {
                            estado = -99;
                            i = i - 2;
                            coluna = coluna - 2;
                            lexema = "";
                        }
                        break;
                    case 4:
                        if (c == '"')
                        {
                            lexema += c;
                            estado = 5;
                        }
                        break;
                    case 5:
                        if (c != '"')
                        {
                            lexema += c;
                            estado = 5;
                        }
                        else
                        {
                            estado = 6;
                            i--;
                            coluna--;
                        }
                        break;
                    case 6:
                        if (c == '"')
                        {
                            lexema += c;
                            addToken(lexema, "Aspas Duplas", fila, coluna, i - lexema.Length);
                            estado = 0;
                            lexema = "";
                        }
                        else if (c == ',')
                        {
                            lexema += c;
                            addToken(lexema, "Virgula", fila, coluna, i - lexema.Length);
                            estado = 0;
                            lexema = "";
                        }

                        break;

                    case 8:
                        if (Char.IsDigit(c))
                        {
                            estado = 9;
                            lexema += c;
                        }
                        else
                        {
                            addError(lexema, "Era esperado um digito (" + lexema + ")", fila, coluna);
                            estado = 0;
                            lexema = "";
                        }
                        break;
                    case 9:
                        if (Char.IsDigit(c))
                        {
                            estado = 9;
                            lexema += c;
                        }
                        else
                        {
                            addToken(lexema, "Digito", fila, coluna, i - lexema.Length);
                            lexema = "";
                            i--;
                            coluna--;
                            estado = 0;
                        }

                        break;

                    case -99:
                        lexema += c;


                        addError(lexema, "Carácter Desconhecido", fila, coluna);

                        estado = 0;
                        lexema = "";
                        break;
                }
            }


        }

        public Boolean Macht_enReser(String sente)
        {
            Boolean enco = false;
            for (int i = 0; i < tokens.Count; ++i)
            {
                if (sente.ToString() == tokens[i].ToString())
                {
                    enco = true;
                    estado_token = i;
                    return enco;
                }
                else if (reservadas.Contains(";" + sente.ToString() + ";"))
                {
                    enco = true;
                    return enco;
                }
                else { enco = false; }

            }
            return enco;
        }

        public void gerarLista()
        {
            for (int i = 0; i < listaTokens.Count; i++)
            {
                Token atual = listaTokens.ElementAt(i);
                retorno += " Linha: " + atual.getlinha() + " Lexema: " + atual.getLexema() + " TokenTipo: " + atual.getIdToken() + Environment.NewLine;
            }
        }
        public String getRetorno()
        {
            return this.retorno;
        }

        public List<Token> getListaTokens()
        {
            return listaTokens;
        }


    }
}
