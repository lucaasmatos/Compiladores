﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoComp
{
    class Token
    {

        private String lexema;
        private String idToken;
        private int linha;
        private int coluna;
        private int indice;
        public Token(String lexema, String idToken, int linha, int coluna, int indice)
        {

            this.lexema = lexema;
            this.idToken = idToken;
            this.linha = linha;
            this.coluna = coluna;
            this.indice = indice;
        }

        public int getIndice()
        {
            return this.indice;
        }
        public String getLexema()
        {
            return this.lexema;
        }
        public String getIdToken()
        {
            return this.idToken;
        }
        public int getlinha()
        {
            return this.linha;
        }
        public int getcoluna()
        {
            return this.coluna;
        }
    }
}
