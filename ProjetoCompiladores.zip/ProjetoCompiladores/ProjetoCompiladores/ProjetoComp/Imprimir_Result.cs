﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoComp
{
 

    public class Imprimir_Result
    {
        String expressao;
        double resultado;

        public Imprimir_Result(String expresion, double resultado)
        {

            this.expressao = expresion;
            this.resultado = resultado;

        }

        public String getExpresion()
        {
            return this.expressao;
        }

        public double getResultado()
        {
            return this.resultado;
        }

  
    }


}
