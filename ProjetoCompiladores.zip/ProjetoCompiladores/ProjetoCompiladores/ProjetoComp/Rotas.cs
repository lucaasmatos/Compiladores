﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoComp
{
    class Rotas
    {

        private string path;
        private String Nome;

        public Rotas(string path, String Nome)
        {

            this.path = path;
            this.Nome = Nome;
        }
        public string getPath()
        {
            return this.path;
        }
        public String getNome()
        {
            return this.Nome;
        }
      
    }
}
